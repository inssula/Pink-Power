
from machine import Pin
import onewire, time
import machine
import ds18x20
import network, socket, ure
import ubinascii
import micropython
import network
import time
import esp
from umqttsimple import MQTTClient
import ntptime
import json
import os



def TimeSync(TechMsgsList):
  global rtc
  ntptime.host = "1.europe.pool.ntp.org"
  txt_Prev = getTime(rtc)  
  ntptime.settime()
  TechMessages("TimeSync","Time was updated, previous: " + txt_Prev + "    Now: "+ getTime(rtc), TechMsgsList)
 
def TechMessages(typ,zprava_msg,seznam):
  global rtc
  seznam.append({'time':getTime(rtc),'type':typ,'message': zprava_msg})
  #client.publish(b'ite/pink/tech',b"{'time',"+str(getTime())+",'type':"+str(typ)+", 'message':"+str(zprava_msg)+"}")

def getTime(rtc):  
  #rtc = machine.RTC()
  #cas_ted = rtc.datetime()
  #print(len(cas_ted))
  #print(rtc.datetime())
  #cas = rtc.datetime().isoformat('T',"microseconds")
  x = list(rtc.datetime())
  cas = "{0:04d}-{1:02d}-{2:02d}T{4:02d}:{5:02d}:{6:02d}.{7:06d}".format(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7])
  #cas = ""+str(cas_ted[0])+"-"+str(cas_ted[1])+"-"+str(cas_ted[2])+"T"+str(cas_ted[4])+":"+str(cas_ted[5])+":"+str(cas_ted[6])+"."+str(cas_ted[7])
  
  return cas

def sub_cb(topic, msg):
  global topic_sub_control
  print((topic, msg))
  
  #Control format: Auth:  Id zarizeni - odvysilano pri prvnim spojeni |  Type:  Command (do something) / Setting (Change something) | module:  what does it refer to | state:   What to change it to (Array of params)
  if(topic == (topic_sub_control)):
    global client_id
    zprava = json.loads(msg)
    if(zprava['auth'] == client_id):
      
      if(zprava['type'] == "command"):
        if(zprava['module'] == "temp"):
          global firstRun 
          firstRun = True
        if(zprava["module"] == "restart"):
          global HardErr, seznam
          TechMessages("Response","Restartuji dle vyžádání",seznam)
        if(zprava)
          #machine.reset()
      
      
      global seznam
      TechMessages("ControlCommand","Agree",seznam)
      
    
    
  
  #TechMessages("state", "OK")
  blink(1)
   
def connect_and_subscribe():
  global client_id, mqtt_server, topic_sub, mqtt_pass, mqtt_user, mqtt_port, topic_sub_tech, topic_sub_control
  client = MQTTClient(client_id, mqtt_server,mqtt_port,mqtt_user,mqtt_pass)
  client.set_callback(sub_cb)
  client.connect()
  client.subscribe(topic_sub)
  client.subscribe(topic_sub_tech)
  client.subscribe(topic_sub_control)
  print('Connected to %s MQTT broker, subscribed to %s topic' % (mqtt_server, topic_sub))
  return client

def restart_and_reconnect():
  print('Failed to connect to MQTT broker. Reconnecting...')
  time.sleep(10)
  machine.reset()

def blink(pocet):
  global led
  minicounter = 0
  while(minicounter < pocet):
    led.value(0)
    time.sleep_ms(100)
    led.value(1)
    minicounter = minicounter + 1

def deep_sleep(msecs):
  #Nefunguje - problém naší desky
  rtc = machine.RTC()
  rtc.irq(trigger=rtc.ALARM0, wake=machine.DEEPSLEEP)

  # set RTC.ALARM0 to fire after X milliseconds (waking the device)
  rtc.alarm(rtc.ALARM0, msecs)
  rtc.alarm(rtc.ALARM0, msecs+10)
  # put the device to sleep
  machine.deepsleep()

if __name__ == "__main__":
  HardErr = False
  gottenMSG = ""
  #vzorovyString = "{'team_name': {0}, 'created_on': '2020-03-24T15:26:05.336974', 'temperature': {1}}"
  #vzorovyString = "{0},  {1}, {2}" 
  message_interval = 60
  team_name = "pink"
  last_message = time.time()
  led = Pin(2,Pin.OUT)
  led.value(1)  
  last_timeUpdate =""
  #jak casto aktualizovat cas [hodiny]
  timeMultiplier = 1
  #Rada zprav
  TempMsgsList = []
  TechMsgsList = []
  global ssid, station,password, mqtt_server
  storing = False
  
  
  rtc = machine.RTC()
  #rtc.ntp_sync("1.europe.pool.ntp.org",1800,"3.europe.pool.ntp.org")
  
  #print(rtc.synced())
  
  print("--------------------")
  print(station.ifconfig())
  
  
  sensor_Pin = Pin(4)
  ds = ds18x20.DS18X20(onewire.OneWire(sensor_Pin))
  client = ""
  try:
    client = connect_and_subscribe()
    TechMessages("MQTT","Connected to: "+mqtt_server,TechMsgsList)
  except OSError as e:
    restart_and_reconnect()
    
    
 
  mezi = True
  #TimeSync(client)
  while(mezi):
    try:
      TimeSync(TechMsgsList)
      last_timeUpdate = time.time()
      mezi = False
    except OSError as e:
      print("Get Time: Failed, trying again in 5s!  " + e)
      TechMessages("Time", "Error, Time could not be synchronized, retry in 5s",TechMsgsList)
      led.value(0)
      time.sleep(5)
      led.value(1)
     
        
  
  TechMessages("Wifi","Connected to: "+ ssid, TechMsgsList)
  romky = ds.scan()
  print("Nalezeno tolik zarizeni: " , len(romky))
  TechMessages("ThermoMeters", "Count "+str(len(romky)) ,TechMsgsList)
  
  
  #metr.on()
  #for i in range(10):
  
  print("--------------------")
  print("--------------------")
  
  firstRun = True
  
  prevMsg = ""
  
  while(True):
        
        #time.sleep_ms(1000)

      #current_time = time.strftime("%Y-%m-%dT%H:%M:%S.%f", t)
      
      
    if ((firstRun == True) or ((time.time() - last_message) >= message_interval)) :
      try:
        ds.convert_temp()
      except:
        #print("lel")
        TechMessages("Thermometers","Error - Thermometers could not be found, Restarting",TechMsgsList)
        blink(10)
        print("Thermo")
        HardErr = True
        
      counter = 0
      for rom in romky:
        counter += 1 

        TempMsgsList.append({'team_name': team_name, 'created_on': getTime(rtc) , 'temperature' : ds.read_temp(rom)})
       
        last_message = time.time()
   
      firstRun = False
      
    #except OSError as e:
    #  led.value(0)
    #  time.sleep_ms(500)
    #  led.value(1)
    #  TechMessages('Error','Unexpected err ocured at ' + getTime(rtc) + "   and required Restart: " + str(e) ,TechMsgsList)
    #  print("Unexpected")
    #  print(e)
    #  HardErr = True
      
      
    if(station.isconnected()):
      
      if(storing == True):
        try:
          client = connect_and_subscribe()
          storing = False  
        except:
          print("Chyba neni na vasem prijimaci")
      
      
      try:    
        zprava = client.check_msg()
        if(len(TempMsgsList) > 0):
          print("posting TEMP: " + str(len(TempMsgsList)))
          for i in TempMsgsList:
            
            client.publish(topic_sub,json.dumps(i))
            time.sleep_ms(100)
            zprava = client.check_msg()
            TempMsgsList.pop(0)
            
          

        if(len(TechMsgsList) > 0):
          print("posting TECH: " + str(len(TechMsgsList)))
          for i in TechMsgsList:
            
            #print(i)
            #print(i)
            client.publish(b'ite/pink/tech',json.dumps(i))            
            time.sleep_ms(500)
            zprava = client.check_msg()
            TechMsgsList.pop(0)
            #zprava = client.check_msg()
             
        
      except OSError as e:
        client.dropConnection()
        #if(storing == False):
        #  print("PublishErr" + str(e))
        #  TechMessages("MQTT","Error Unexpectedly disconnected",TechMsgsList)        
        #  client.dropConnection()        
        #client = connect_and_subscribe()
        
      
      #storing = False
      
    else:
      if(storing == False):
        print("Wifi Disconnected")
        storing = True
        TechMessages("Wifi","Detected disconnected wifi at " + getTime(rtc),TechMsgsList)
        client.dropConnection()
      #station.connect(ssid,password)     
      
    if((time.time() - last_timeUpdate) >= 3600 * timeMultiplier):
      TimeSync(TechMsgsList)
      print("TimeSynced")
      last_timeUpdate = time.time()
    if(HardErr == True):
      machine.reset()
      #print()
      
      #deep_sleep(5000)
      
    
# Nahravani Binary
# esptool.py --port COM4 --baud 460800 write_flash  --flash_size=detect 0 c:/Users/Dangel/Desktop/ite/Semestralka/esp8266base.bin
# Smazani Flashe
# esptool.py --port COM4 erase_flash

#nahravani Programu: 
# put main.py

#stazeni programu:
# get main.py

#mpfshell -> repl  na pristup k serivove lince



