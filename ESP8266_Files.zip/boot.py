
# This file is executed on every boot (including wake-boot from deepsleep)

#import esp

#esp.osdebug(None)

import uos, machine

#uos.dupterm(None, 1) # disable REPL on UART(0)

import gc

#import webrepl

#webrepl.start()


import time
from umqttsimple import MQTTClient
import ubinascii
import machine
import micropython
import network
import esp
esp.osdebug(None)
import gc
gc.collect()

ssid = '#SSID'
password = '#PASSWORD'

mqtt_server = '#MQTTSERVER'
mqtt_port = 1883
mqtt_user = "#MQTTUSER"
mqtt_pass = "#MQTTPASSWORD"

#EXAMPLE IP ADDRESS
#mqtt_server = '192.168.1.144'
client_id = ubinascii.hexlify(machine.unique_id())
topic_sub = b'ite/pink'
topic_pub = b'ite/pink'
topic_sub_tech = topic_sub + b'/tech'
topic_sub_control = topic_sub+b'/control'

station = network.WLAN(network.STA_IF)

station.active(True)
station.connect(ssid, password)

while station.isconnected() == False:
  pass

print('Connection successful')



